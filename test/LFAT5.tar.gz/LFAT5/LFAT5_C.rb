Oberwolfach/LFAT5_C                                                    |1440C   
             2             1             1             0
pra                        1            14             1             0
(40I2)          (40I2)                              
 1 1 1 1 1 1 1 1 2 2 2 2 2 2 2
 1
