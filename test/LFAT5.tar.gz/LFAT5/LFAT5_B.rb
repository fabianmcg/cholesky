Oberwolfach/LFAT5_B                                                    |1440B   
             2             1             1             0
pra                       14             1             1             0
(40I2)          (26I3)                              
 1 2
  8
